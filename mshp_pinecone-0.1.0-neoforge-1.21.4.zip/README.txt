# Мод «Шишка»

Мод для Minecraft, разработанный АНО ДО «Московская школа программистов».  
В моде представлен персонаж Шишка — фирменный маскот организации.

## Установка
1. Убедитесь, что у вас установлена версия Minecraft **1.21.4**.
2. Установите соответствующую версию **NeoForge** для этой версии Minecraft.
3. Поместите файл мода `mshp_pinecone-0.1.0-neoforge-1.21.4` в папку:
   ```
   .minecraft/mods
   ```
4. Запустите Minecraft с установленным NeoForge.

## Правовая информация
Персонаж «Шишка» является объектом авторского права и товарным знаком организации, использован с разрешения.  
Мод некоммерческий, распространяется только в неизменённом виде.  
При любом публичном использовании мода (видео, сборки, публикации и т.п.) должно быть указано, что мод создан Московской школой программистов, и приведена ссылка:  
👉 https://mshp.informatics.ru/minecraft
Не аффилирован с Mojang AB или Microsoft.

## Разработка
Дизайн и реализация: Дмитрий Шершнев

## Контакт
Дополнительная информация: [https://mshp.informatics.ru/minecraft](https://mshp.informatics.ru/minecraft)

---

# Pinecone Mod

A Minecraft mod officially developed by ANO DO “Moscow Programming School”.  
Features the organization’s mascot — Pinecone — as a custom mob.

## Installation
1. Make sure you have Minecraft **version 1.21.4** installed.
2. Install the matching version of **NeoForge** for Minecraft 1.21.4.
3. Place the mod file `mshp_pinecone-0.1.0-neoforge-1.21.4` into your:
   ```
   .minecraft/mods
   ```
4. Launch Minecraft with NeoForge selected.

## Legal
The character Pinecone is a trademark and copyrighted creation of the organization, used with permission.  
This mod is non-commercial and distributed in original, unmodified form only.  
When used publicly (e.g. in videos, modpacks, articles), this mod must be credited to Moscow Programming School with a link to:  
👉 https://mshp.informatics.ru/minecraft
Not affiliated with Mojang AB or Microsoft.

## Development
Design and implementation: Dmitrii Shershnev

## Contact
More information: [https://mshp.informatics.ru/minecraft](https://mshp.informatics.ru/minecraft)
